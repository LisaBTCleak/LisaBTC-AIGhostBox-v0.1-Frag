
# LisaBTC - BTC Whale Tracker (Leak Fragment - Obfuscated)

import json
import time
import requests
import asyncio
import websockets

BTC_PRICE_API = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd"
MIN_BTC_THRESHOLD = 10

def fetch_price():
    try:
        return requests.get(BTC_PRICE_API, timeout=5).json()["bitcoin"]["usd"]
    except:
        return 0

def log_detection(sender, receiver, amount, tx_hash):
    print(f"[+] BTC Whale Detected: {amount:.2f} BTC")
    print(f"    From: {sender} → To: {receiver}")
    print(f"    TX: https://www.blockchain.com/btc/tx/{tx_hash}")
    print(f"    Note: Full classification & AI tracking is unavailable in this build.")

async def process_tx(tx):
    try:
        out_total = sum(o.get("value", 0) for o in tx.get("out", [])) / 1e8
        if out_total < MIN_BTC_THRESHOLD:
            return

        tx_hash = tx.get("hash")
        ins = [i.get("prev_out", {}) for i in tx.get("inputs", [])]
        outs = tx.get("out", [])

        sender = ins[0].get("addr", "Unknown") if ins else "Unknown"
        receiver = outs[0].get("addr", "Unknown") if outs else "Unknown"

        log_detection(sender, receiver, out_total, tx_hash)

    except Exception as e:
        print(f"[-] Processing error: {e}")

async def mempool_ws():
    url = "wss://ws.blockchain.info/inv"
    while True:
        try:
            async with websockets.connect(url, ping_timeout=30) as ws:
                await ws.send(json.dumps({"op": "unconfirmed_sub"}))
                print("[*] LisaBTC Leak Live: Listening to BTC mempool...")
                while True:
                    msg = await ws.recv()
                    data = json.loads(msg)
                    if data.get("op") == "utx":
                        await process_tx(data.get("x"))
        except Exception as e:
            print(f"[!] Reconnecting to mempool: {e}")
            await asyncio.sleep(5)

def main():
    print("[+] LisaBTC Ghost Fragment Active.")
    asyncio.run(mempool_ws())

if __name__ == "__main__":
    main()
