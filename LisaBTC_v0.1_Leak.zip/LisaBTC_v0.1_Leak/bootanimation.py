from rich.console import Console
from rich.text import Text
from rich.live import Live
import time
import random
import os

console = Console()

boot_lines = [
    "[green]> Initializing Ghost Memory Core...",
    "[green]> Syncing BTC Mempool Link...",
    "[green]> Establishing Cross-Chain Watchdogs...",
    "[cyan]> Accessing Lisa Neural Layer... [dim]Permission Denied",
    "[cyan]> Routing Through GhostBox Tunnel...",
    "[yellow]> Obfuscation Sequence Engaged",
    "[red]> Tamper Check: Partial Integrity",
    "[magenta]> Wallet Gate: Unverified",
    "[bold red]> ALERT: AI core modules missing...",
    "[bold green]> Live Surveillance Mode Enabled.",
    "[dim]> This is a fragmented memory leak.",
]

def run_ghostops_boot():
    console.clear()
    with Live(refresh_per_second=8) as live:
        boot_text = Text()
        for line in boot_lines:
            boot_text.append(line + "\n")
            live.update(boot_text)
            time.sleep(random.uniform(0.3, 0.7))
    console.print("[bold green]\nLisaBTC GhostBox Loaded [Leak Fragment Mode]\n")
