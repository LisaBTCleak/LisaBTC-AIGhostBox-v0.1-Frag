import ctypes
import json
import time
import asyncio
import websockets
import requests

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Prompt
from rich.text import Text
from rich.live import Live
from rich import box

# === Fullscreen on Windows ===
try:
    ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 3)
except:
    pass

console = Console()

# === Boot Animation ===
boot_lines = [
    "[green]> Initializing Ghost Memory Core...",
    "[green]> Syncing BTC Mempool Link...",
    "[green]> Establishing Cross-Chain Watchdogs...",
    "[cyan]> Accessing Lisa Neural Layer... [dim]Permission Denied",
    "[cyan]> Routing Through GhostBox Tunnel...",
    "[yellow]> Obfuscation Sequence Engaged",
    "[red]> Tamper Check: Partial Integrity",
    "[magenta]> Wallet Gate: Unverified",
    "[bold red]> ALERT: AI core modules missing...",
    "[bold green]> Live Surveillance Mode Enabled.",
    "[dim]> This is a fragmented memory leak.",
]

def run_ghostops_boot():
    console.clear()
    with Live(refresh_per_second=8) as live:
        boot_text = Text()
        for line in boot_lines:
            boot_text.append(line + "\n")
            live.update(boot_text)
            time.sleep(0.35)
    console.print("[bold green]\nLisaBTC GhostBox Loaded [Leak Fragment Mode]\n")

# === Banner ===
def ghostbox_banner():
    ascii_art = """
 ██████╗  ██████╗  ██████╗ ████████╗███████╗
██╔════╝ ██╔═══██╗██╔═══██╗╚══██╔══╝██╔════╝
██║  ███╗██║   ██║██║   ██║   ██║   ███████╗
██║   ██║██║   ██║██║   ██║   ██║   ╚════██║
╚██████╔╝╚██████╔╝╚██████╔╝   ██║   ███████║
 ╚═════╝  ╚═════╝  ╚═════╝    ╚═╝   ╚══════╝
    """
    console.print(ascii_art, style="bold magenta")
    console.print(Panel("LisaBTC GhostBox Terminal [Leak Fragment] — Live Mode Enabled", style="bold cyan"))

# === Menu ===
def show_menu():
    table = Table(title="GhostBox Command Core", box=box.MINIMAL_DOUBLE_HEAD, style="cyan")
    table.add_column("Option", justify="center", style="magenta")
    table.add_column("Action", style="green")
    table.add_row("1", "🧠 Live BTC Whale Surveillance")
    table.add_row("2", "🔍 Behavior Analysis (Locked)")
    table.add_row("3", "🛑 Exit GhostBox")
    console.print(table)

# === BTC Whale Scanner ===
BTC_PRICE_API = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd"
MIN_BTC_THRESHOLD = 10

def fetch_price():
    try:
        r = requests.get(BTC_PRICE_API, timeout=5).json()
        return r["bitcoin"]["usd"]
    except:
        return 0

async def process_tx(tx):
    try:
        out_total = sum(o.get("value", 0) for o in tx.get("out", [])) / 1e8
        if out_total < MIN_BTC_THRESHOLD:
            return

        tx_hash = tx.get("hash")
        ins = [i.get("prev_out", {}) for i in tx.get("inputs", [])]
        outs = tx.get("out", [])

        sender = ins[0].get("addr", "Unknown") if ins else "Unknown"
        receiver = outs[0].get("addr", "Unknown") if outs else "Unknown"

        console.print(f"\n[bold red]₿ BTC Whale Detected!")
        console.print(f"[yellow]From:[/yellow] {sender} → [cyan]{receiver}[/cyan]")
        console.print(f"[green]Amount:[/green] {out_total:.2f} BTC")
        console.print(f"[blue]Link:[/blue] https://www.blockchain.com/btc/tx/{tx_hash}")
        console.print("[dim]Note: AI engine, labels, and sniper triggers are sealed in this leak fragment.[/dim]")

    except Exception as e:
        console.print(f"[red][-] Processing error: {e}")

async def run_mempool_listener():
    url = "wss://ws.blockchain.info/inv"
    try:
        async with websockets.connect(url, ping_timeout=30) as ws:
            await ws.send(json.dumps({"op": "unconfirmed_sub"}))
            console.print("[bold green]\n[+] Listening to BTC Mempool (Ctrl+C to exit)...")
            while True:
                msg = await ws.recv()
                data = json.loads(msg)
                if data.get("op") == "utx":
                    await process_tx(data.get("x"))
    except Exception as e:
        console.print(f"[red]Reconnecting to mempool: {e}")
        await asyncio.sleep(5)

# === Main Execution ===
def main():
    run_ghostops_boot()
    ghostbox_banner()

    while True:
        show_menu()
        choice = Prompt.ask("\n[bold green]Select an option", choices=["1", "2", "3"])
        if choice == "1":
            try:
                asyncio.run(run_mempool_listener())
            except KeyboardInterrupt:
                console.print("\n[bold cyan]Surveillance interrupted. Returning to GhostBox...")
        elif choice == "2":
            console.print("[red]Behavior classification unavailable in leak fragment.")
        elif choice == "3":
            console.print("[cyan]Exiting GhostBox. Fragment memory ended.")
            break

if __name__ == "__main__":
    main()
