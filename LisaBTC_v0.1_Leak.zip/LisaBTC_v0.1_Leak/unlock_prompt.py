from rich.prompt import Prompt

code = Prompt.ask("[red]Enter Lisa Unlock Code")
if code != "ACCESS-GHOST-042":
    print("[bold red]Access Denied.")
    exit()